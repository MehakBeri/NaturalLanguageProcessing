/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postagging;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 *
 * @author Mehak Beri
 */
public class BrillsTransformation {
    
    
    public static void main(String[] args) throws IOException {
       String d= System.getProperty("user.dir");
       File in= new File(d+"\\HW2_F17_NLP6320_POSTaggedTrainingSet-Windows.txt");
       System.out.println("Ques 3, Part b");
       Scanner sc= new Scanner(in);
       Map<String, Integer> Unigrams= new LinkedHashMap<>(); //hashmap to store each unique combination of word_tag in corpus, used linkedhashmap to preserve order
       HashSet<String> word; //set to store all unique words that occur in training set
       
       Map<String,String> mostProb= new TreeMap<>(); //hashmap containing most probable tag for each word
        word = new HashSet<>();
       String token="";
       int i=0;
       String[] arr= new String[2];
       while(sc.hasNext())
       {
           i=0;
           token=sc.next();
           for(String r: token.split("_"))
           {
               arr[i]=r;
               i++;
           }
           word.add(arr[0]);
           if(Unigrams.containsKey(token)){
               Unigrams.put(token,Unigrams.get(token)+1);
           }
           else{
               Unigrams.put(token, 1);
           }
       }
     //  System.out.format("%32s%16s\r\n\r\n","WORD_TAG","FRQUENCY");
      // for(Map.Entry<String,Integer> entry: Unigrams.entrySet()){
        // System.out.format("%32s%16d\r\n",entry.getKey(),entry.getValue());
      //}
       
       //for each unique word, find out the values in Unigram hashmap, which start with that word. then find out which combo of that word has maximum freq. store that word n tag in mostprob hashmap
       int max=0,l;
       String ans="";
       String[] mpt=new String[2];
       for(String s: word)
       {
           Set<String> freq= Unigrams.keySet().stream().filter(x-> x.startsWith(s+"_")).collect(Collectors.toSet());
           //finds word_tag with max frequency
           for(String f: freq)
           {
               if(Unigrams.get(f)>max)
               {
                   max=Unigrams.get(f);
                   ans=f;
               }
               
           }
           max=0;
           l=0;
           for(String y: ans.split("_"))
           {
               mpt[l]=y;
               l++;
           }
           mostProb.put(mpt[0], mpt[1]);
       }
       //re-tag corpus based on most probable tags and store in file: corpus_tagged_with_MPT.txt
       FileWriter f1= new FileWriter("corpus_tagged_with_MPT.txt");
       PrintWriter p1= new PrintWriter(f1);
       String a;
       String[] ad= new String[2];
       Scanner sc0= new Scanner(in);
       while(sc0.hasNext())
       {
           a=sc0.next();
           ad= a.split("_");
           p1.print(ad[0]+"_"+mostProb.get(ad[0])+" ");
       }
       
       p1.close();
       System.out.println("Corpus tagged with initial Most Probable tags for each word stored in file named: corpus_tagged_with_MPT.txt\n\n");
       // iterate to get templates
       File mpt_tagged= new File(d+"\\corpus_tagged_with_MPT.txt");
       int iteration=1;
       Integer ErrorCorrectionCount=100;
       String rules= ""; //to store rules in each iterations
       String prev="";
       String curr="";
       Scanner ss= new Scanner(System.in);
       String returned="";
       String prevReturn="a";
     while(!prevReturn.equals(returned=template_creator(in,mpt_tagged,iteration)))
      {
       
       
       //returned string to store returned values of form "transformation:error-correction-count"
      // System.out.println(returned);
       String[] tb= new String[2];
       int u=0;
       for(String g: returned.split("="))
       {
           tb[u]=g;
           u++;
       }
       rules += "Rule"+iteration+":- "+tb[0]+"     Error-Correction-Count:- "+tb[1]+"\r\n";
       //rule added to final file. now apply this top rule to the corpus
       
       ErrorCorrectionCount= Integer.valueOf(tb[1]);
       //now apply the top rule to the corpus
       u=0;
       String[] r= new String[3];
       for(String s: tb[0].split(" "))
       {
           r[u]=s;
           u++;
       }
       // r[0] is from; r[1] is prev word tag; r[2] is to tag in the top rule
       u=0;
       for(String s: r[0].split(":"))
       {
           tb[u]=s;
           u++;
       }
       String from_tag= tb[1];
       u=0;
       for(String s: r[1].split(":"))
       {
           tb[u]=s;
           u++;
       }
       String prev_tag= tb[1];
       u=0;
       for(String s: r[2].split(":"))
       {
           tb[u]=s;
           u++;
       }
       String to_tag= tb[1];       
       Scanner sc2= new Scanner(mpt_tagged);
       FileWriter f2=new FileWriter("corpus_retagged_with_mostProbTag_after_template_"+iteration+".txt");
       PrintWriter p2= new PrintWriter(f2);
       int k=0;
       while(sc2.hasNext())
       {
           curr=sc2.next();
           String[] t= new String[2];
           String[] p= new String[2];
           t=curr.split("_");
           if(prev!="")
           {
               
               p=prev.split("_");
           }
           
           if((t[1].equals(from_tag))&&(p[1].equals(prev_tag)))
           {
              
               p2.print(t[0]+"_"+to_tag+" ");
               k++;
           }
           else{
               p2.print(curr+" ");
           }
           prev=curr;
       }
       p2.close();
     
       mpt_tagged= new File(d+"\\corpus_retagged_with_mostProbTag_after_template_"+iteration+".txt");
       System.out.println("Corpus retagged with top rule from template "+ iteration+ " stored in file: corpus_retagged_with_mostProbTag_after_template_"+iteration+".txt\n\n");
       iteration++;
       prevReturn=returned;
   }
       
       FileWriter f=new FileWriter("Rules.txt"); //collection of top transformation rule from each template obtained in each iteration
       PrintWriter p=new PrintWriter(f);
       p.print(rules);
       System.out.println("Since prev template is equal to the current template, program stopped creating templates containing new transformation rules. Final file containing top transformation rule from each template obtained in each iteration stored in file: Rules.txt");
       p.close();
    }
    
    public static String template_creator(File in, File mpt_tagged, int i) throws IOException
    {
       Map<String,Integer> m= new TreeMap<String,Integer>(); //hashmap to store transformation and error count of that transformation
       String[] t= new String[2];
       String[] p=new String[2];
       String[] n=new String[2];
       int j=0;
       String prev="";
       String curr="";
       String mp_curr;
       Scanner sc1= new Scanner(in);
       Scanner mp=new Scanner(mpt_tagged);
       String table;
       while(sc1.hasNext())
       {
           curr=sc1.next();
           mp_curr=mp.next();
           for(String s: curr.split("_"))
           {
               t[j]=s;
               j++;
           }
           j=0;
           for(String s: prev.split("_"))
           {
               p[j]=s;
               j++;
           }
           j=0;
           for(String s: mp_curr.split("_"))
           {
               n[j]=s;
               j++;
           }
           j=0;
           //t[0] is word, t[1] is corresponding tag; check if tag of word matches the most probable tag
           
           if(!((t[1].equals(n[1]))&&(t[0].equals(n[0]))))
           {
               //System.out.println("For the word "+curr+" given tag is: "+t[1]+" whereas most probable tag is: "+mostProb.get(t[0])+". Its prev word is: "+prev+" and prev tag is "+p[1]);
               table= "FROM:"+n[1]+" PREV-WORD-TAG:"+p[1]+" TO:"+t[1];
               
               if(m.containsKey(table))
               {
                   m.put(table, m.get(table)+1);
               }
               else{
                   m.put(table,1);
               }
           }//now take into account those instances when the tags are correctly placed in the text even though we have a rule against that.
           
           prev=curr;
       }
       
       
       
       j=0;
       Scanner sc11= new Scanner(in);
       Scanner mp1=new Scanner(mpt_tagged);
      
       while(sc11.hasNext())
       {
           curr=sc11.next();
           mp_curr=mp1.next();
           for(String s: curr.split("_"))
           {
               t[j]=s;
               j++;
           }
           j=0;
           for(String s: prev.split("_"))
           {
               p[j]=s;
               j++;
           }
           j=0;
           for(String s: mp_curr.split("_"))
           {
               n[j]=s;
               j++;
           }
           j=0;
           //t[0] is word, t[1] is corresponding tag; check if tag of word matches the most probable tag
           
          //now take into account those instances when the tags are correctly placed in the text even though we have a rule against that.
           Set<String> ec= m.keySet().stream().filter(x-> x.startsWith("FROM:"+n[1]+" PREV-WORD-TAG:"+p[1])).collect(Collectors.toSet());
           if(((t[1].equals(n[1]))&&(t[0].equals(n[0]))))
           {
               
               for(String s: ec)
               {
                   m.put(s, m.get(s)-1);
               }
               
           }
           
           prev=curr;
       }      
              
       Map<String,Integer> sorted= new LinkedHashMap<>();
       int highest=0;
       List<String> toRemove=new ArrayList<String>();
      
       while(!m.keySet().isEmpty())
       {
           highest=Collections.max(m.values());
           for(Map.Entry<String,Integer> ee: m.entrySet())
           {
               if(ee.getValue()==highest)
               {
                   
                   sorted.put(ee.getKey(),ee.getValue());
                   toRemove.add(ee.getKey());
               }
           }
           for(String y: toRemove)
           {
               m.remove(y);
           }
       }
       FileWriter f= new FileWriter("template"+i+".txt");
       System.out.println("Rule Set "+i+" stored in file named: 'template"+i+".txt' containing "+sorted.size()+" rules.");
       PrintWriter pw= new PrintWriter(f);
       pw.printf("%48s%32s\r\n\r\n","FROM_PREV-WORD-TAG_TO","ERROR-CORRECTION-COUNT");
       int h=0;
       String ans="";
       for(Map.Entry<String,Integer> ee: sorted.entrySet())
       {
           if(h==0)
           {
               ans=ee.getKey()+"="+ee.getValue();
               h++;
           }
           pw.printf("%48s%32d\r\n",ee.getKey(),ee.getValue());
           
       }
       pw.close();
       System.out.println("Transformation Rule Selected: "+ans);
       return ans;
      
       
    }

}
