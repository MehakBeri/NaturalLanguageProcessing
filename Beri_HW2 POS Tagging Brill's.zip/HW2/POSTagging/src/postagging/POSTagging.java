/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postagging;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 *
 * @author Mehak Beri
 */
public class POSTagging {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
       String d= System.getProperty("user.dir");
       File in= new File(d+"\\HW2_F17_NLP6320_POSTaggedTrainingSet-Windows.txt");
       System.out.println("Ques 3, Part a");
       Scanner sc= new Scanner(in);
       Map<String, Integer> Unigrams= new TreeMap<>(); //hashmap to store each unique combination of word_tag in corpus
       HashSet<String> word; //set to store all unique words that occur in training set
       Map<String,String> mostProb= new TreeMap<>(); //hashmap containing most probable tag for each word
        word = new HashSet<>();
       String token="";
       int i=0;
       String[] arr= new String[2];
       while(sc.hasNext())
       {
           i=0;
           token=sc.next();
           for(String r: token.split("_"))
           {
               arr[i]=r;
               i++;
           }
           word.add(arr[0]);
           if(Unigrams.containsKey(token)){
               Unigrams.put(token,Unigrams.get(token)+1);
           }
           else{
               Unigrams.put(token, 1);
           }
       }
       System.out.println("Frequency of occurence of a combination of Word_Tag stored in file: freq.txt");
       FileWriter filewriter= new FileWriter("freq.txt");
       PrintWriter printwriter= new PrintWriter(filewriter);
       printwriter.printf("%32s%16s\r\n\r\n","WORD_TAG","FRQUENCY");
       for(Map.Entry<String,Integer> entry: Unigrams.entrySet()){
           printwriter.printf("%32s%16d\r\n",entry.getKey(),entry.getValue());
       }
       //for each unique word, find out the values in Unigram hashmap, which start with that word. then find out which combo of that word has maximum freq. store that word n tag in mostprob hashmap
       int max=0,l;
       String ans="";
       String[] mpt=new String[2];
       for(String s: word)
       {
           Set<String> freq= Unigrams.keySet().stream().filter(x-> x.startsWith(s+"_")).collect(Collectors.toSet());
           //finds word_tag with max frequency
           for(String f: freq)
           {
               if(Unigrams.get(f)>max)
               {
                   max=Unigrams.get(f);
                   ans=f;
               }
               
           }
           max=0;
           l=0;
           for(String y: ans.split("_"))
           {
               mpt[l]=y;
               l++;
           }
           mostProb.put(mpt[0], mpt[1]);
       }
       printwriter.close();
       System.out.println("Most Probable tag for each word, based on the frequency of occurence in the training corpus, stored in file: mostProbableTag.txt");
       FileWriter filewriter1= new FileWriter("mostProbableTag.txt");
       PrintWriter printwriter1= new PrintWriter(filewriter1);
       printwriter1.printf("%32s%32s\r\n\r\n", "WORD","MOST PROBABLE TAG");
       for(Map.Entry<String,String> en: mostProb.entrySet())
       {
           printwriter1.printf("%32s%32s\r\n", en.getKey(),en.getValue());
       }
       printwriter1.close();
       
       //re-tag corpus based on most probable tags and store in file: corpus_tagged_with_MPT.txt
       FileWriter f1= new FileWriter("corpus_tagged_with_MPT.txt");
       PrintWriter p1= new PrintWriter(f1);
       String a;
       String[] ad= new String[2];
       Scanner sc0= new Scanner(in);
       while(sc0.hasNext())
       {
           a=sc0.next();
           ad= a.split("_");
           p1.print(ad[0]+"_"+mostProb.get(ad[0])+" ");
       }
       
       p1.close();
       System.out.println("Corpus tagged with Most Probable tags for each word stored in file named: corpus_tagged_with_MPT.txt");
    }
    
}
