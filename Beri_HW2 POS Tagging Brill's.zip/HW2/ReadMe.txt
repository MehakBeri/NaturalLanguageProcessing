HOMEWORK 2
STUDENT NET ID: mxb166430 | MEHAK BERI

Ques 1: 
Code written in Java. Import project 'bigramProb' into NetBeans IDE. (My version is NetBeans IDE 8.2). Place the corpus file named "HW2_F17_NLP6320-NLPCorpusTreebank2Parts-CorpusA-Windows.txt" in the main folder of the project called 'bigramProb'. 
In the file tree, you shall see two files in 'bigramProb>src>bigramprob'.
Run First file: "BigramProb.java" to get the count and probability of all bigrams in the corpus. The counts and probabilities are displayed in the output console and are stored in an external file called 'CorpusCountOutput.txt' as well. You can access this file inside the main folder of project called 'bigramProb'.
Run second file: "TestBigram.java" to compute bigram probabilities on a given sentence. In the output console, enter the test sentence. The needed output is displayed in the output console and is stored in an external file called 'testCaseOutput.txt' as well. You can access this file inside the main folder of project called 'bigramProb'.

Ques 2: 
The answer to question 2 is stored in a text file called 'Ques 2.txt'

Ques 3: 
Code written in Java. Import project 'POSTagging' into NetBeans IDE. (My version is NetBeans IDE 8.2). Place the corpus file named "HW2_F17_NLP6320_POSTaggedTrainingSet-Windows.txt" in the main folder of the project called "Transformation Based POS Tagging".
In the file tree, you shall see three files, one for each part of this question. 3(a) in POSTagging.java, 3(b) in BrillsTransformation.java and 3(c) in TestBrills.java
3(a) On running POSTagging.java, the files created are stored in the main folder of the project. Frequency of occurence of a combination of Word_Tag stored in file: freq.txt. (UNIGRAM MODEL)Most Probable tag for each word, based on the frequency of occurence in the training corpus, stored in file: mostProbableTag.txt. Corpus tagged with Most Probable tags for each word stored in file named: corpus_tagged_with_MPT.txt
3(b) On running BrillsTransformation.java, the files created are stored in the main folder of the project. Corpus tagged with initial Most Probable tags for each word stored in file named: corpus_tagged_with_MPT.txt. The rules created in each iteration are stored in files named 'template1.txt' 'template2.txt' etc. The rule with maximum error correction count in each of template is selected and added to the final file called 'Rules.txt'. The corpus is tagged repeatedly using these files and these intermediate files are also stored in the main folder. 
3(c) On running TestBrills.java, the files created are stored in the main folder of the project. Corpus tagged with initial Most Probable tags for each word stored in file named: corpus_tagged_with_MPT.txt. The rules created in each iteration are stored in files named 'template1.txt' 'template2.txt' etc. The rule with maximum error correction count in each of template is selected and added to the final file called 'Rules.txt'. The corpus is tagged repeatedly using these files and these intermediate files are also stored in the main folder. The sentence to be tested is tested against model a and model b and the error rate from both cases is displayed in the output console.
