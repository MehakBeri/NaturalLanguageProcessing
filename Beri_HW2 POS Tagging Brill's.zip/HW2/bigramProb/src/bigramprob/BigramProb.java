/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigramprob;
import java.io.*;
import java.net.URL;
import java.util.*;
/**
 *
 * @author Mehak Beri
 */
public class BigramProb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        
        String d=System.getProperty("user.dir");
        
        File in = new File(d+"//HW2_F17_NLP6320-NLPCorpusTreebank2Parts-CorpusA-Windows.txt");
        
        System.out.println("QUES1, PART1: COMPUTING BIGRAM COUNTS ON GIVEN CORPUS");
        Scanner sc= new Scanner(in);
        int n=0; //total number of tokens
        int v=0; //number of UNIQUE tokens in the vocabulary
        Map<String,Integer> hm=new LinkedHashMap<String,Integer>();  //hashmap stores unigram counts
        Map<String,Integer> hmb= new LinkedHashMap<String,Integer>(); //hashmap to store bigram counts
        int b=0; //total number of bigrams
        String prev="";
        String first="";
        String token="";
        while(sc.hasNext())
        {
            token=sc.next();
            if(n==0)
            {
                first=token;
                prev=token;
            }
            n++;
            if(hm.containsKey(token))
            {
                hm.put(token, hm.get(token) + 1);
                
            }
            if(hmb.containsKey(prev+" "+token))
            {
                hmb.put((prev+" "+token),hmb.get(prev+" "+token)+1);
                
            }
            if(!hm.containsKey(token))
            {
                hm.put(token,1);
            }
            if(!hmb.containsKey(prev+" "+token))
            { 
                hmb.put((prev+" "+token), 1);
                
            }
            
            prev=token;
        }
        hmb.remove(first+" "+first);
        v= hm.size();
        b=n-1;        
        int bigramCount= hmb.size();
        float prob;
        FileWriter filewriter= new FileWriter("CorpusCountOutput.txt");
        PrintWriter printwriter= new PrintWriter(filewriter);
        System.out.println("\n Total number of tokens: "+n);
        printwriter.print("\r\n Total number of tokens: "+n+"\r\n");
        System.out.println("\n Number of unique tokens: "+v);
        printwriter.print("\r\n Number of unique tokens: "+v+"\r\n");
        System.out.println("\n Total number of bigrams: "+b);
        printwriter.print("\r\n Total number of bigrams: "+b+"\r\n");
        System.out.println("\n Number of unique bigrams: "+bigramCount);
        printwriter.print("\r\n Number of unique bigrams: "+bigramCount+"\r\n");
        System.out.println("\n BIGRAM COUNTS AND PROBABILITIES FOR THE INPUT CORPUS");
        System.out.println("(These have also been stored in a txt file called CorpusCountOutput.txt)");
        printwriter.print("\r\n BIGRAM COUNTS FOR THE INPUT CORPUS\r\n");
        System.out.format("\n%32s%16s%16s\n","Bigram","Count","Probability");
        printwriter.printf("\r\n%32s%16s%16s\r\n","Bigram","Count","Probability");
        for(Map.Entry<String,Integer> entry: hmb.entrySet()){
            prob= (float)entry.getValue()/ b;
            System.out.format("%32s%16d%16f\n",entry.getKey(),entry.getValue(),prob);
            printwriter.printf("%32s%16d%16f\r\n",entry.getKey(),entry.getValue(),prob);
        }
        
        sc.close();
        printwriter.close();
        
    }
    
}
