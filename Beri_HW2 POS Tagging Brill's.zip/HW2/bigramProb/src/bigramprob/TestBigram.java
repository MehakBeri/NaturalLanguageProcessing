/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigramprob;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Mehak Beri
 */
public class TestBigram {
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        String d=System.getProperty("user.dir");        
        File in = new File(d+"//HW2_F17_NLP6320-NLPCorpusTreebank2Parts-CorpusA-Windows.txt"); 
       
        System.out.println("QUES1, PART2");
        Scanner sc= new Scanner(in);
        int n=0; //number of tokens=N
        int v=0; //number of unique tokens in the vocabulary
        Map<String,Integer> hm=new LinkedHashMap<String,Integer>();  //hashmap stores unigram counts
        Map<String,Integer> hmb= new LinkedHashMap<String,Integer>(); //hashmap to store bigram counts
        String token="";
        String prev="";
        String first="";
        while(sc.hasNext())
        {
            token=sc.next();
            if(n==0)
            {
                first=token;
                prev=token;
            }
            n++;
            if(hm.containsKey(token))
            {
                hm.put(token, hm.get(token) + 1);
                
            }
            if(hmb.containsKey(prev+" "+token))
            {
                hmb.put((prev+" "+token),hmb.get(prev+" "+token)+1);
            }
            if(!hm.containsKey(token))
            {
                hm.put(token,1);
            }
            if(!hmb.containsKey(prev+" "+token))
            { 
                hmb.put((prev+" "+token), 1);
            }
            
            prev=token;
        }
        hmb.remove(first+" "+first);
        v= hm.size();
        sc.close();
        Scanner sc2= new Scanner(System.in);
        System.out.println("Bigram Language Model Trained!\nPlease input a sentence to test against this model: ");
        String in2= sc2.nextLine();
        String[] words= in2.split(" ");
        int l=words.length;
        FileWriter filewriter= new FileWriter("testCaseOutput.txt");
        PrintWriter printwriter= new PrintWriter(filewriter);
        printwriter.print("Input sentence for test case is: "+in2+"\r\n");
        //bigram counts for the sentence
        System.out.println("\nBigram counts for the sentence:");
        printwriter.print("\r\nBigram counts for the sentence:\r\n");
        float[] ws= new float[l]; //array to store bigram counts without smoothing
        float[] ao= new float[l]; //array to store bigram counts for add one smoothing
        float[] gt= new float[l]; //array to store bigram counts for good turing
        float freqNum;
        float freqDen;
        Integer c;
        System.out.println("\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing");
        printwriter.print("\r\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing\r\n");
        for(int i=0; i<l-1; i++)
        {   
            
                c=hmb.get(words[i]+" "+words[i+1]);
                if(c==null)
                {
                    ws[i]=0;
                    gt[i]=0;
                }
                else
                {
                    ws[i]= c;
                    freqNum=Collections.frequency(hmb.values(),c+1 ); //number of bigrams with count c+1
                    
                    freqDen=Collections.frequency(hmb.values(), c); //numbr of bigrams with count c
                    
                    gt[i]= ((ws[i]+1)*freqNum)/freqDen;
                }
                ao[i]=ws[i]+1;
                
                System.out.format("%32s%16f%20f%20f", words[i]+" "+words[i+1]+" : ", ws[i], ao[i], gt[i]);
                printwriter.printf("%32s%16f%20f%20f\r\n", words[i]+" "+words[i+1]+" : ", ws[i], ao[i], gt[i]);
                
                System.out.println();
                
            
        }
        
        //bigram probabilities for the sentences
        System.out.println("\nBigram probability for the sentence:");
        printwriter.print("\r\nBigram probability for the sentence:\r\n");
        float[] ws1= new float[l]; //array to store bigram prob without smoothing
        float[] ao1= new float[l]; //array to store bigram prob for add one smoothing
        float[] gt1= new float[l]; //array to store bigram prob for good turing
        
        System.out.println("\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing");
        printwriter.print("\r\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing\r\n");
        for(int g=0; g<l-1;g++)
        {
           
                if(hm.containsKey(words[g]))
                        {
                ws1[g]= ws[g]/(float)hm.get(words[g]);
                ao1[g]= ao[g]/((float)v+(float)hm.get(words[g]));
                        }
                else
                {
                    ws1[g]= 0;
                    ao1[g]= 0;
                }
                if(gt[g]==0)
                {
                    gt1[g]=(Collections.frequency(hmb.values(), 1))/(float)n;
                }
                else
                {
                    gt1[g]= gt[g]/(float)n;
                }
                System.out.format("%32s%16f%20f%20f", words[g]+" "+words[g+1]+" : ", ws1[g], ao1[g], gt1[g]);
                printwriter.printf("%32s%16f%20f%20f\r\n", words[g]+" "+words[g+1]+" : ", ws1[g], ao1[g], gt1[g]);
                
                System.out.println();
            
            
        }
        
        //total probability of the sentence
        System.out.println("\nTotal probability of the sentence:");
        printwriter.print("\r\nTotal probability of the sentence:\r\n");
        double ws2=1, ao2=1, gt2=1;
        System.out.println("\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing");
        printwriter.print("\r\n\t\t\t\tWithout Smoothing         Add One Smoothing       Good Turing\r\n");
        for(int x=0; x<l-1; x++)
        {
           ws2*=ws1[x];
           ao2*=ao1[x];
           gt2*=gt1[x];    
        }
        System.out.format("%32s%16.3E%20.3E%20.3E", "", ws2, ao2, gt2);
        printwriter.printf("%32s%16.3E%20.3E%20.3E", "", ws2, ao2, gt2);
      
        System.out.println();
        System.out.println("\n\nOutput for this test case stored in file named: testCaseOutput.txt");
        printwriter.close();
    }
    
    
}
