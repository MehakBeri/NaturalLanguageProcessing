1. Code for Viterbi algorithm written in Java in the file called "Viterbi.java".
2. Open command prompt. Go to the directory in which the Viterbi.java file is located.
3. Enter "javac Viterbi.java"
4. Enter "java Viterbi"
5. You will be prompted to enter the observation sequence (eg-313, 231321 etc)
6. Press enter after entering the observation sequence. You shall see probabilities for different observations for different states on the screen. The last line will give the final probability as well as the backtrace.
7. State 1 is "HOT" and State 2 means "COLD"
8. Answer to question 2 is given in pdf - "Answer2-ParseTrees"