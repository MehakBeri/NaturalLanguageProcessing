/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Mehak Beri
 */
public class Viterbi {

        public static void main(String[] args) {
        // Implementing viterbi algorithm
        Scanner sc= new Scanner(System.in);
        System.out.println("Please input the observation sequence:");
        String obs= sc.next();
        //transition probability= matrix a; STATES ARE q0=start, q1=hot and q2=cold
        double a[][]= {{0,0.8,0.2},{0,0.7,0.3},{0,0.4,0.6}};
        //state observation likelihood; 1=hot; 2=cold; b11=b(1|hot) ; row=observation; col=state
        
        double b[][]={{0,0,0},{0,0.2,0.5},{0,0.4,0.4},{0,0.4,0.1}};
        
        String[] q= {"START","HOT","COLD"}; //states q0, q1 and q2
        int n= q.length;
        //no. of obsrvations
        int t= obs.length();
        String[] Observation_Symbols= obs.split("");
        int[] os= new int[t];
        int j=0;
        for(String s: Observation_Symbols)
        {
            os[j]=Integer.parseInt(s);
            j++;
        }
        //path probability matrix
        double[][] viterbi;
        viterbi = new double[n+2][t];
        String[] backtrace= new String[t+1];
        int observation;
        
        //initialization
        for(int i=1; i<n;i++) //for each state s from 1 to n
        {
            observation=os[0]; //first observation
            viterbi[i][0]=(a[0][i])*(b[observation][i]);
            backtrace[0]=q[0]; 
        }
        
        //recursive step
        double max=0;
        double temp=0;
        double maxh=0;
        int m=0;
        for(int k=1; k<t; k++)
        {
            maxh=0;
            for(int s=1; s<n;s++){
                max=0;
                m=0;
                for(int h=1; h<n; h++)
            {
                temp=viterbi[h][k-1]*a[h][s]*b[os[k]][s];
               // System.out.println("temp: "+viterbi[h][k-1]+" * "+a[h][s]+" * "+b[os[k]][s]+" = "+temp);
                if(temp>=max)
                {
                    max=temp;
                    m=h;
                    
                }                    
            }
            viterbi[s][k]=max;
            temp=viterbi[s][k];
            if(temp>=maxh)
            {
                backtrace[k]=q[m];
                maxh=temp;
            }
            }
            
        }
        
        System.out.println("\nState 1 represents 'HOT'; State 2 represents 'COLD'; Viterbi matrix has states as its rows and observation indexes as its columns:- viterbi[state][observation no.]\n");
        for(int i=0; i<t;i++)
        {
            for(int l=1; l<n;l++)
            {
                System.out.println("viterbi["+l+"| obs"+i+"]: "+viterbi[l][i]);
                System.out.println("(backtrace) PREV STATE: "+backtrace[i]);
                System.out.println();
            }
        }
     
        
        //termination step; qF= final state= (max of viterbi value from prev state)*af[i]; first state=start state=viterbi[0][i]
     
        double finalProb=0;
        int maxS=0;
        for(int i=1; i<n; i++)
        {
            if(viterbi[i][t-1]>finalProb)
            {
                finalProb=viterbi[i][t-1];
                maxS=i;
            }
          
        }
        backtrace[t]=q[maxS];
        System.out.println("Termination step, final probability: "+finalProb);
        System.out.print("Backtrace: ");
        for(int i=0; i<t+1;i++)
        {
            System.out.print(backtrace[i]+"->");
        }
        System.out.println("END");
        
    }
}
